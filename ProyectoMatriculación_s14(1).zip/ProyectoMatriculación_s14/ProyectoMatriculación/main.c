#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"

int main (){
	int opcion1, opcion;

	do{
		printf("1. Registrarse\n");
		printf("2. Iniciar sesi�n\n");
		printf("3. Salir\n");
		printf("Elige una opci�n: ");
		scanf("%d", &opcion1);
		system("cls");
		
		switch (opcion1) {
		case 1:
			registrarUsuario();
			system("pause");
			break;
		case 2:
			if (iniciarSesion()) { //Si el se inicia sesi�n correctamente pasamos a lo siguiente
				
				do {
					system("cls");
					menuVehiculos();
					scanf("%d", &opcion);
					system("cls");
					switch (opcion) {
					case 1:
						registrarVehiculo();
						break;
					case 2:
						calculoMatricula();			
						break;
					case 3:
						buscarVehiculoPlaca();
						break;
					case 4:
						listarVehiculos();
						break;
					case 5:
						printf("Saliendo del sistema...\n");
						break;
					default:
						printf("Opci�n inv�lida.\n");
						break;
					}
					system("pause");
				} while (opcion != 5);
			} else {
				printf("No se pudo iniciar sesi�n. Int�ntalo nuevamente.\n");
				system("pause");
			}
			break;
		case 3:
			printf("Saliendo del programa......\n");
			system("pause");
			break;
		default:
			printf("Opci�n no v�lida, por favor selecciona una opci�n v�lida.\n");
			system("pause"); //se detiene temporalmente y muestra un mensaje como el presionar enter
			break;
		}
		
		system("cls");
		
	} while(opcion1 != 3);
	
	return 0;	
}
	
