#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"

int main (){
	int opcion;
	
	do {
		system("cls");
		menuVehiculos();
		scanf("%d", &opcion);
		system("cls");
		switch (opcion) {
		case 1:
			registrarVehiculo();
			break;
		case 2:
			calculoMatricula();			
			break;
		case 3:
			buscarVehiculoPlaca();
			break;
		case 4:
			listarVehiculos();
			break;
		case 5:
			printf("Saliendo del sistema...\n");
			break;
		default:
			printf("Opci�n inv�lida.\n");
			break;
		}
		system("pause");
	} while (opcion != 5);
	
	return 0;	
}
	
